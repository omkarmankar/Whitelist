<?php

require '../../vendor/autoload.php';

/* $GLOBALS['client']='client';
$GLOBALS['collection']='collection'; */

 $client = new MongoDB\Client("mongodb://localhost:27017");
 $collection = $client->whitelist->data;
?>
