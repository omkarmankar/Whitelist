<?php
require '../../vendor/autoload.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
require 'database.php';

  $cursor = $collection->find();
  $array = array();
  foreach ($cursor as $document) {
  array_push($array,$document);
  }
  echo json_encode($array);
 
/*
function getDomainCategories(){
  $cursor = $GLOBALS['collection']->find();
  $array = array();
  foreach ($cursor as $document) {
  array_push($array,$document['categoryName']);
  }
  echo json_encode($array);
}
function getSubCategories($index){
  $cursor = $GLOBALS['collection']->find(['categoryId'=>$index]);
  var_dump($cursor);
 $array = array();
  foreach ($cursor as $document) {
  array_push($array,$document);
  }
  echo json_encode($array); 
}*/
?>