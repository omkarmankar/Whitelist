import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { dataSample } from "./../classes/whitelistDataFormat";

@Injectable({
  providedIn: "root"
})
export class ApiService {
  getSubCategories() {
    throw new Error("Method not implemented.");
  }
  private webUrl: string = "http://localhost/angularDemo/backend";
  constructor(private httpClient: HttpClient) {}

  readJson(): Observable<any> {
    return this.httpClient.get<any>(`${this.webUrl}/api/read.php`);
    }
}
