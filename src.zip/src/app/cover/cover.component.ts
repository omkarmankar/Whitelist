import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-cover",
  templateUrl: "./cover.component.html",
  styleUrls: ["./cover.component.css"]
})
export class CoverComponent implements OnInit {
  constructor() {}
  /* public data:dataSample[];
  constructor(private _ApiService: ApiService) {}
  ngOnInit() {
    this._ApiService.readCategoryData().subscribe(data=>this.data=data) ;
  }*/ 
  ngOnInit() {
        var btn = $('#button');

    $(window).scroll(function() {
      if ($(window).scrollTop() > 300) {
        btn.addClass('show');
      } else {
        btn.removeClass('show');
      }
    });

    btn.on('click', function(e) {
      e.preventDefault();
      $('html, body').animate({scrollTop:0}, '300');
    });


  }
}
