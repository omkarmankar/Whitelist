export class dataSample {
  categoryId: number;
  categoryName: string;
  subCategoryName: string;
  webId: number;
  webSiteName: string;
  webLink: string;
  typeOfLink: string;
  Language: string;
  keyWords: string;
  webShortDesc: string;
  webLongDesc: string;
}
