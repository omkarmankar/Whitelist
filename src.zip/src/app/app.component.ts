import { Component } from "@angular/core";
import { ApiService } from "./services/api.service";
import {dataSample} from "./classes/whitelistDataFormat";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  //title = "whitelist";
  public data:dataSample[];
  constructor(private _ApiService: ApiService) {}
  ngOnInit() {
    this._ApiService.readJson().subscribe(data=>this.data=data) ;
  }
}
