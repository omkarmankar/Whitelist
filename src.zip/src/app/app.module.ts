import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { NavbarComponent } from "./navbar/navbar.component";
import { CoverComponent } from "./cover/cover.component";
import { DomainComponent } from "./domain/domain.component";
import { FooterComponent } from "./footer/footer.component";
import { ApiService } from "./services/api.service";

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    CoverComponent,
    DomainComponent,
    FooterComponent
  ],
  imports: [BrowserModule, HttpClientModule, AppRoutingModule],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule {}
