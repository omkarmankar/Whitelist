import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-domain',
  templateUrl: './domain.component.html',
  styleUrls: ['./domain.component.css']
})
export class DomainComponent implements OnInit {
  public allData = [];
  public category = [];
  public subCategoryArr = [];
  public currentCategory: string = "Domains";
  public currentIndex: number;
  public showSubCategory: boolean = false;
  public showCategories: boolean = true;
  public websiteData = [];
  constructor(private _apiService: ApiService) { }

  ngOnInit() {
    this._apiService.readJson().
      subscribe(data => {
        this.allData = data;
        this.getCategory();
      });
  }
  getCategory() {
    for (let i = 0; i < this.allData.length; i++) {
      this.category.push(this.allData[i].categoryName);
    }
  }
  getSubCategory(index) {
    this.showSubCategory = true;
    this.currentIndex = index;
    let length = this.allData[index]['subCategory'].length;
    if (length > 0) {
      this.category = [];
      this.currentCategory = this.allData[index]['categoryName'];
      console.log(this.currentCategory);
      for (let i = 0; i < this.allData[index]['subCategory'].length; i++) {
        this.category.push(this.allData[index]['subCategory'][i].subCategoryName);
      }
    }
  }
  getWebsiteData(index: number) {
    this.showCategories = false;
    this.showSubCategory = true;
    console.log(index);
    this.currentCategory = this.allData[this.currentIndex]['subCategory'][index]['subCategoryName'];
    let length = this.allData[this.currentIndex]['subCategory'][index]['subCategoryData'].length;
    if (length > 0) {
      this.category = [];
      for (let i = 0; i < length; i++) {
        let obj = {
          name: this.allData[this.currentIndex]['subCategory'][index]['subCategoryData'][i].webSiteName,
          link: this.allData[this.currentIndex]['subCategory'][index]['subCategoryData'][i].webLink
        }
        console.log(obj);
        this.websiteData.push(obj);
      }
    }
  }
  OpenInNewTabWinBrowser(url) {
    var win = window.open(url, '_blank');
    win.focus();
  }
}

